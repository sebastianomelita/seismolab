Simple arduino library to sync the time with an ESP8266 WIFI module over NTP.

For more details (e.g. how to setup the ESP8266 module) refer to my blog at http://tiny.cc/a15esx

####Buy me a beer
I am working on this in my spare time. So if you want to buy me a beer, please click the Donate-Button on my blog.
